/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { RecordPage } from './pages/RecordPage';
import { TrajectoryPage } from './pages/TrajectoryPage';
import { ProfilePage } from './pages/ProfilePage';
import { ConfirmationPage } from './pages/ConfirmationPage';
import { BottomNav } from './components/BottomNav';
import { usePersistence } from './hooks/usePersistence';
import { Direction, Log } from './types';
import { signInWithPopup, googleProvider, auth, signOut } from './firebase';

export default function App() {
  const [activeTab, setActiveTab] = useState('record');
  const { 
    logs, directions, user, firebaseUser, isReady, 
    addLog, addDirection, removeDirection, updateDirectionsOrder 
  } = usePersistence();
  
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [completionState, setCompletionState] = useState<{ 
    active: boolean; 
    directionName: string; 
    count: number 
  }>({
    active: false,
    directionName: '',
    count: 0
  });

  const handleLogin = async () => {
    if (isLoggingIn) return;
    setIsLoggingIn(true);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error: any) {
      if (error.code === 'auth/popup-blocked') {
        alert('登录弹窗被拦截，请允许弹窗后重试。');
      } else if (error.code === 'auth/cancelled-popup-request') {
        console.log('Login request cancelled');
      } else {
        console.error('Login failed:', error);
      }
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  const handleAddLog = async (directionId: string, content: string) => {
    const direction = directions.find(d => d.id === directionId);
    if (!direction) return;

    const newLog: Log = {
      id: Math.random().toString(36).substr(2, 9),
      uid: user?.uid || 'anonymous',
      directionId,
      directionName: direction.name,
      content,
      timestamp: new Date().toISOString()
    };
    
    await addLog(newLog);

    // Calculate count for this direction
    const count = logs.filter(l => l.directionId === directionId).length + 1;

    setCompletionState({
      active: true,
      directionName: direction.name,
      count
    });
  };

  const renderPage = () => {
    if (!isReady) return <div className="flex items-center justify-center min-h-screen text-text-muted">Loading...</div>;
    
    if (!firebaseUser) {
      return (
        <div className="flex flex-col items-center justify-center min-h-screen px-8 space-y-8 animate-in fade-in duration-700">
          <div className="text-center space-y-2">
            <h1 className="text-4xl font-medium text-brand-primary tracking-tight">寸进</h1>
            <p className="text-sm text-text-muted font-medium tracking-widest">INCHING</p>
          </div>
          <p className="text-center text-text-secondary leading-relaxed max-w-[280px]">
            记下你做了什么，<br/>看见自己走了多远。
          </p>
          <button
            onClick={handleLogin}
            disabled={isLoggingIn}
            className="w-full max-w-xs bg-brand-primary text-white py-4 rounded-full font-medium shadow-lg hover:shadow-brand-primary/20 transition-all active:scale-95 disabled:opacity-50"
          >
            {isLoggingIn ? '正在登录...' : '开始探索'}
          </button>
        </div>
      );
    }

    switch (activeTab) {
      case 'record':
        return <RecordPage directions={directions} logs={logs} onAddLog={handleAddLog} />;
      case 'trajectory':
        return <TrajectoryPage logs={logs} directions={directions} />;
      case 'profile':
        return (
          <ProfilePage 
            user={user} 
            onLogout={handleLogout} 
            directions={directions}
            onAddDirection={addDirection}
            onRemoveDirection={removeDirection}
          />
        );
      default:
        return <RecordPage directions={directions} logs={logs} onAddLog={handleAddLog} />;
    }
  };

  return (
    <div className="min-h-screen bg-bg-white pb-20 overflow-x-hidden font-sans text-text-primary">
      {renderPage()}
      
      {completionState.active && (
        <ConfirmationPage 
          directionName={completionState.directionName}
          count={completionState.count}
          onClose={() => setCompletionState(prev => ({ ...prev, active: false }))}
        />
      )}

      {firebaseUser && <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />}
    </div>
  );
}

