export interface Direction {
  id: string;
  uid: string;
  name: string;
  order: number;
}

export interface Log {
  id: string;
  uid: string;
  directionId: string;
  directionName: string;
  content: string;
  timestamp: string; // ISO string
}

export interface UserProfile {
  uid: string;
  email: string;
  onboardingCompleted: boolean;
}
