import { useState, useEffect } from 'react';
import { Log, Direction, UserProfile } from '../types';
import { 
  auth, db, onAuthStateChanged, User, 
  collection, query, where, onSnapshot, setDoc, doc, updateDoc, 
  handleFirestoreError, OperationType, orderBy, deleteDoc, getDocs
} from '../firebase';

export function usePersistence() {
  const [logs, setLogs] = useState<Log[]>([]);
  const [directions, setDirections] = useState<Direction[]>([]);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [isReady, setIsReady] = useState(false);

  // Handle Auth
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setFirebaseUser(u);
      if (u) {
        setUser({
          uid: u.uid,
          email: u.email || '',
          onboardingCompleted: true
        });
      } else {
        setUser(null);
      }
      setIsReady(true);
    });
    return () => unsubscribe();
  }, []);

  // Sync Directions
  useEffect(() => {
    if (!firebaseUser) {
      setDirections([]);
      return;
    }

    const q = query(collection(db, 'directions'), where('uid', '==', firebaseUser.uid), orderBy('order', 'asc'));
    const unsubscribe = onSnapshot(q, async (snapshot) => {
      const data = snapshot.docs.map(doc => doc.data() as Direction);
      
      // Seed default directions if empty
      if (data.length === 0 && snapshot.metadata.fromCache === false) {
        const defaults = ['英语', '剪辑', '文案', '营销', '传播', '产品'];
        const seedBatch = defaults.map((name, index) => {
          const id = Math.random().toString(36).substr(2, 9);
          return setDoc(doc(db, 'directions', id), {
            id,
            uid: firebaseUser.uid,
            name,
            order: index
          });
        });
        await Promise.all(seedBatch);
      } else {
        setDirections(data);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'directions');
    });

    return () => unsubscribe();
  }, [firebaseUser]);

  // Sync Logs
  useEffect(() => {
    if (!firebaseUser) {
      setLogs([]);
      return;
    }

    const q = query(collection(db, 'logs'), where('uid', '==', firebaseUser.uid), orderBy('timestamp', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => doc.data() as Log);
      setLogs(data);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'logs');
    });

    return () => unsubscribe();
  }, [firebaseUser]);

  const addLog = async (log: Log) => {
    if (!firebaseUser) return;
    try {
      await setDoc(doc(db, 'logs', log.id), log);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `logs/${log.id}`);
    }
  };

  const addDirection = async (name: string) => {
    if (!firebaseUser) return;
    const id = Math.random().toString(36).substr(2, 9);
    const newDir: Direction = {
      id,
      uid: firebaseUser.uid,
      name,
      order: directions.length
    };
    try {
      await setDoc(doc(db, 'directions', id), newDir);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `directions/${id}`);
    }
  };

  const removeDirection = async (id: string) => {
    if (!firebaseUser) return;
    try {
      await deleteDoc(doc(db, 'directions', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `directions/${id}`);
    }
  };

  const updateDirectionsOrder = async (newDirections: Direction[]) => {
    if (!firebaseUser) return;
    try {
      const updates = newDirections.map((dir, index) => 
        updateDoc(doc(db, 'directions', dir.id), { order: index })
      );
      await Promise.all(updates);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'directions/order');
    }
  };

  return {
    logs,
    directions,
    user,
    firebaseUser,
    isReady,
    addLog,
    addDirection,
    removeDirection,
    updateDirectionsOrder,
    setUser
  };
}
