import React from 'react';
import { PenLine, Activity, User } from 'lucide-react';
import { cn } from '../lib/utils';

interface BottomNavProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const tabs = [
  { id: 'record', label: '记录', icon: PenLine },
  { id: 'trajectory', label: '轨迹', icon: Activity },
  { id: 'profile', label: '我的', icon: User },
];

export function BottomNav({ activeTab, onTabChange }: BottomNavProps) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 h-20 bg-white border-t border-gray-100 flex items-center justify-around px-4 pb-4">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className="flex flex-col items-center justify-center space-y-1 transition-colors"
          >
            <Icon
              className={cn(
                "w-6 h-6",
                isActive ? "text-brand-primary" : "text-gray-400"
              )}
            />
            <span
              className={cn(
                "text-xs font-medium",
                isActive ? "text-brand-primary" : "text-gray-400"
              )}
            >
              {tab.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
}
