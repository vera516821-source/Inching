import React, { useEffect } from 'react';
import { motion } from 'motion/react';
import { Direction } from '../types';

interface ConfirmationPageProps {
  directionName: string;
  count: number;
  onClose: () => void;
}

export function ConfirmationPage({ directionName, count, onClose }: ConfirmationPageProps) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 1500);
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-50 bg-bg-white flex flex-col items-center justify-center p-8">
      <div className="space-y-4 text-center mb-16 px-4">
        <p className="text-xl font-medium text-text-primary">记下来了。</p>
        
        <div className="py-8">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 200, damping: 15 }}
            className="flex flex-col items-center gap-4"
          >
            <div className="flex items-baseline gap-2">
              <span className="text-sm text-text-secondary">第</span>
              <span className="text-5xl font-medium text-brand-primary tracking-tight">{count}</span>
              <span className="text-sm text-text-secondary">次推进</span>
            </div>
            <p className="text-lg font-medium text-text-primary px-6 py-2 bg-brand-light rounded-full text-brand-primary">
              {directionName}
            </p>
          </motion.div>
        </div>
      </div>

      <button
        onClick={onClose}
        className="text-sm font-medium text-brand-primary border border-brand-primary/20 px-8 py-3 rounded-full hover:bg-brand-light transition-all active:scale-95"
      >
        再记一条 →
      </button>

      <p className="fixed bottom-12 text-[10px] text-text-muted uppercase tracking-[0.2em]">
        Inch by inch, your growth is visible.
      </p>
    </div>
  );
}
