import React, { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { Direction, Log } from '../types';
import { cn } from '../lib/utils';

interface RecordPageProps {
  directions: Direction[];
  logs: Log[];
  onAddLog: (directionId: string, content: string) => void;
}

export function RecordPage({ directions, logs, onAddLog }: RecordPageProps) {
  const [selectedDirectionId, setSelectedDirectionId] = useState<string | null>(null);
  const [content, setContent] = useState('');
  
  const handleSave = () => {
    if (!selectedDirectionId) return;
    onAddLog(selectedDirectionId, content);
    setContent('');
    // Typically the parent handles navigation to confirmation
  };

  return (
    <div className="flex flex-col min-h-screen bg-bg-white px-6 pt-12 pb-24">
      <div className="flex justify-between items-baseline mb-12">
        <h1 className="text-2xl font-medium text-text-primary uppercase tracking-tight">寸进</h1>
        <span className="text-sm text-text-muted">
          {format(new Date(), 'M月d日 EEEE', { locale: zhCN })}
        </span>
      </div>

      <p className="text-xl font-medium text-text-primary mb-8">今天做了什么？</p>

      <div className="space-y-8 flex-1">
        <div>
          <p className="text-xs text-text-muted uppercase tracking-widest mb-4">方向（单选）</p>
          <div className="flex flex-wrap gap-2">
            {directions.map((dir) => (
              <button
                key={dir.id}
                onClick={() => setSelectedDirectionId(dir.id)}
                className={cn(
                  "px-4 py-2 rounded-full text-sm font-medium transition-all border",
                  selectedDirectionId === dir.id
                    ? "bg-brand-primary border-brand-primary text-white shadow-md shadow-brand-primary/20"
                    : "bg-transparent border-border-ease text-text-secondary hover:border-brand-medium"
                )}
              >
                {dir.name}
              </button>
            ))}
          </div>
        </div>

        <div className="relative group">
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value.slice(0, 60))}
            placeholder="写一句话就够"
            className="w-full bg-bg-subtle rounded-3xl p-6 text-text-primary placeholder:text-text-muted focus:outline-none min-h-[160px] resize-none border border-transparent focus:border-brand-light transition-all"
          />
          <div className="absolute bottom-4 right-6 text-[10px] text-text-muted">
            {content.length}/60
          </div>
        </div>
      </div>

      <button
        onClick={handleSave}
        disabled={!selectedDirectionId}
        className={cn(
          "w-full py-5 rounded-full font-medium text-lg transition-all active:scale-95 shadow-lg",
          selectedDirectionId
            ? "bg-brand-primary text-white shadow-brand-primary/20"
            : "bg-border-ease text-text-muted cursor-not-allowed"
        )}
      >
        记下来
      </button>
    </div>
  );
}
