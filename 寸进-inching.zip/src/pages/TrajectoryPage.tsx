import React, { useState, useMemo } from 'react';
import { format, subDays, startOfDay, isWithinInterval } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { Log, Direction } from '../types';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

interface TrajectoryPageProps {
  logs: Log[];
  directions: Direction[];
}

type TimeRange = 'month' | '3months' | 'all';

export function TrajectoryPage({ logs, directions }: TrajectoryPageProps) {
  const [timeRange, setTimeRange] = useState<TimeRange>('3months');

  const filteredLogs = useMemo(() => {
    const now = new Date();
    let startDate: Date;
    if (timeRange === 'month') startDate = subDays(now, 30);
    else if (timeRange === '3months') startDate = subDays(now, 90);
    else return logs;

    return logs.filter(log => new Date(log.timestamp) >= startDate);
  }, [logs, timeRange]);

  const stats = useMemo(() => {
    const counts: Record<string, number> = {};
    filteredLogs.forEach(log => {
      counts[log.directionId] = (counts[log.directionId] || 0) + 1;
    });

    const data = directions
      .map(dir => ({
        id: dir.id,
        name: dir.name,
        count: counts[dir.id] || 0
      }))
      .filter(d => d.count > 0)
      .sort((a, b) => b.count - a.count);

    const maxCount = data.length > 0 ? data[0].count : 1;
    
    // Insights
    let insightStr = '';
    if (data.length > 0) {
      const top = data[0].name;
      const bottom = data[data.length - 1].name;
      insightStr = `你在${top}上投入最多${data.length > 1 ? ` · ${bottom}最近较少推进` : ''}`;
    }

    return { data, maxCount, insightStr };
  }, [filteredLogs, directions]);

  const timelineDays = useMemo(() => {
    const days: Record<string, Log[]> = {};
    logs.forEach(log => {
      const dayKey = format(new Date(log.timestamp), 'yyyy-MM-dd');
      if (!days[dayKey]) days[dayKey] = [];
      days[dayKey].push(log);
    });
    return Object.entries(days).sort((a, b) => b[0].localeCompare(a[0]));
  }, [logs]);

  return (
    <div className="flex flex-col min-h-screen bg-bg-white px-6 pt-12 pb-24">
      <h1 className="text-2xl font-medium text-text-primary mb-8 px-1">轨迹</h1>

      <div className="mb-10">
        <div className="flex justify-between items-center mb-6">
          <p className="text-xs text-text-secondary font-medium uppercase tracking-widest">
            {timeRange === 'month' ? '过去 30 天' : timeRange === '3months' ? '过去 90 天' : '全部'}
          </p>
          <div className="flex bg-bg-subtle p-1 rounded-full text-[10px] font-medium text-text-muted">
            {(['month', '3months', 'all'] as TimeRange[]).map(r => (
              <button
                key={r}
                onClick={() => setTimeRange(r)}
                className={cn(
                  "px-3 py-1 rounded-full transition-all",
                  timeRange === r ? "bg-white text-brand-primary shadow-sm" : "hover:text-text-secondary"
                )}
              >
                {r === 'month' ? '本月' : r === '3months' ? '3个月' : '全部'}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-4 mb-6">
          <AnimatePresence mode="popLayout">
            {stats.data.map((dir, idx) => (
              <motion.div
                key={dir.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4, delay: idx * 0.08, ease: "easeOut" }}
                className="group"
              >
                <div className="flex justify-between text-xs font-medium mb-1.5">
                  <span className="text-text-primary">{dir.name}</span>
                  <span className="text-text-muted">{dir.count}次</span>
                </div>
                <div className="h-2 w-full bg-border-ease rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${(dir.count / stats.maxCount) * 100}%` }}
                    transition={{ duration: 0.8, delay: idx * 0.1, ease: [0.16, 1, 0.3, 1] }}
                    className="h-full bg-brand-primary rounded-full"
                  />
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
        
        {stats.insightStr && (
          <p className="text-[10px] text-text-muted italic px-1">{stats.insightStr}</p>
        )}
      </div>

      <div className="w-full h-px bg-border-ease mb-10" />

      <div className="space-y-10">
        <h3 className="text-xs text-text-secondary font-medium uppercase tracking-widest px-1">时间线</h3>
        
        <div className="space-y-10">
          {timelineDays.map(([date, dayLogs]) => (
            <div key={date} className="relative pl-6 border-l border-border-ease">
              <div className="absolute -left-[4.5px] top-1 w-2 h-2 rounded-full bg-border-ease" />
              <p className="text-xs font-medium text-text-muted mb-4">
                {format(new Date(date), 'M月d日 周iiiii', { locale: zhCN })}
              </p>
              <div className="space-y-4">
                {dayLogs.map(log => (
                  <div key={log.id} className="group">
                    <span className="inline-block w-1.5 h-1.5 rounded-full bg-brand-medium mr-2" />
                    <span className="text-sm font-medium text-text-primary mr-2">{log.directionName} ·</span>
                    <span className="text-sm text-text-secondary leading-relaxed">
                      {log.content || '完成了推进'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ))}
          
          {logs.length === 0 && (
            <div className="text-center py-20">
              <p className="text-sm text-text-muted">还没有开启任何一段轨迹。</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
