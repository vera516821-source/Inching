import React, { useState } from 'react';
import { UserProfile, Direction } from '../types';
import { ChevronRight, Plus, Trash2, Menu } from 'lucide-react';
import { cn } from '../lib/utils';

interface ProfilePageProps {
  user: UserProfile | null;
  onLogout: () => void;
  directions: Direction[];
  onAddDirection: (name: string) => void;
  onRemoveDirection: (id: string) => void;
}

export function ProfilePage({ user, onLogout, directions, onAddDirection, onRemoveDirection }: ProfilePageProps) {
  const [showDirManagement, setShowDirManagement] = useState(false);
  const [newDirName, setNewDirName] = useState('');

  if (showDirManagement) {
    return (
      <div className="flex flex-col min-h-screen bg-bg-white px-6 pt-12 pb-24">
        <div className="flex items-center gap-4 mb-10">
          <button onClick={() => setShowDirManagement(false)} className="text-text-primary">
            <ChevronRight className="w-6 h-6 rotate-180" />
          </button>
          <h1 className="text-xl font-medium">方向管理</h1>
        </div>

        <p className="text-xs text-text-muted mb-8 italic">最多 8 个方向标签</p>

        <div className="space-y-4 mb-12">
          {directions.map((dir) => (
            <div key={dir.id} className="flex items-center justify-between p-4 bg-bg-subtle rounded-2xl group">
              <div className="flex items-center gap-4">
                <Menu className="w-4 h-4 text-text-muted cursor-move" />
                <span className="text-sm font-medium text-text-primary">{dir.name}</span>
              </div>
              <button 
                onClick={() => onRemoveDirection(dir.id)}
                className="p-2 opacity-0 group-hover:opacity-100 text-text-muted hover:text-red-400 transition-all"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}

          {directions.length < 8 && (
            <div className="flex gap-2 pt-4">
              <input
                type="text"
                value={newDirName}
                onChange={(e) => setNewDirName(e.target.value.slice(0, 10))}
                placeholder="新方向，如：写作"
                className="flex-1 bg-white border border-border-ease rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-brand-primary"
              />
              <button
                onClick={() => {
                  if (newDirName) {
                    onAddDirection(newDirName);
                    setNewDirName('');
                  }
                }}
                className="bg-brand-primary text-white p-3 rounded-xl active:scale-95 transition-all"
              >
                <Plus className="w-5 h-5" />
              </button>
            </div>
          )}
        </div>

        <p className="text-[10px] text-text-muted mt-auto uppercase tracking-widest text-center px-8">
          长按拖拽可排序（开发中）· 删除方向不会删除存下的历史
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen bg-bg-white px-6 pt-12 pb-24">
      <h1 className="text-2xl font-medium text-text-primary mb-12">我的</h1>

      <div className="space-y-1">
        <button 
          onClick={() => setShowDirManagement(true)}
          className="flex items-center justify-between w-full py-6 group"
        >
          <div className="text-left">
            <p className="text-sm font-medium text-text-primary mb-1">方向管理</p>
            <p className="text-xs text-text-muted">自定义你的成长方向</p>
          </div>
          <ChevronRight className="w-5 h-5 text-text-muted group-hover:translate-x-1 transition-transform" />
        </button>
        
        <div className="w-full h-px bg-border-ease" />

        <div className="py-12 space-y-4">
          <h3 className="text-xs text-text-muted font-medium uppercase tracking-widest">关于寸进</h3>
          <p className="text-sm text-text-secondary leading-relaxed">
            寸进 Inching — 当你想做成某件事时，命运已经在拉着你走了
          </p>
        </div>
      </div>

      <div className="mt-auto space-y-6">
        <div className="w-full h-px bg-border-ease" />
        <div className="flex justify-between items-center text-xs text-text-muted">
          <span>{user?.email}</span>
          <button 
            onClick={onLogout}
            className="font-medium text-text-primary hover:text-brand-primary transition-colors"
          >
            退出登录
          </button>
        </div>
      </div>
    </div>
  );
}
